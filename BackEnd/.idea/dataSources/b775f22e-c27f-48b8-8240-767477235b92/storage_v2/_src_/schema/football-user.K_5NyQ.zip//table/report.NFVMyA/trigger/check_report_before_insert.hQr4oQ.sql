create definer = `football-user`@localhost trigger check_report_before_insert
    before insert
    on report
    for each row
BEGIN
    -- 检查postid和userid不同时为空
    IF NEW.postid IS NULL AND NEW.userid IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'postid and userid cannot be both NULL';
    END IF;

    -- 检查是否存在相同的reporterid和postid组合
    IF NEW.postid IS NOT NULL THEN
        IF EXISTS (SELECT * FROM report WHERE reporterid = NEW.reporterid AND postid = NEW.postid) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Duplicate reporterid and postid combination';
        END IF;
    END IF;

    -- 检查是否存在相同的reporterid和userid组合
    IF NEW.userid IS NOT NULL THEN
        IF EXISTS (SELECT * FROM report WHERE reporterid = NEW.reporterid AND userid = NEW.userid) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Duplicate reporterid and userid combination';
        END IF;
    END IF;
END;

