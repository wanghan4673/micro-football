create definer = `football-user`@localhost trigger decrease_likes_count
    after delete
    on likes
    for each row
BEGIN
    UPDATE post
    SET likes = likes - 1
    WHERE _id = OLD.postid AND likes > 0;
END;

