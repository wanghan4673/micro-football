create definer = `football-user`@localhost trigger decrement_collect_count
    after delete
    on collect
    for each row
BEGIN
    UPDATE post
    SET collect = collect - 1
    WHERE _id = OLD.postid AND collect > 0;
END;

