create definer = `football-user`@localhost trigger increment_collect_count
    after insert
    on collect
    for each row
BEGIN
    UPDATE post
    SET collect = collect + 1
    WHERE _id = NEW.postid;
END;

